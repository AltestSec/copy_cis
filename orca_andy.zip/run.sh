#!/bin/sh

echo "Running CIS checks for OS '${OS}'"
exec /home/nixadmin/nix-benchmark/${OS}/run-benchmark.sh
