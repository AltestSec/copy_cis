#!/bin/sh
# ** AUTO GENERATED **

# 6.1.1 - Audit system file permissions (Not Scored)

rpm -Va --nomtime --nosize --nomd5 --nolinkto || exit $?
