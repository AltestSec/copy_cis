#!/bin/sh
# ** AUTO GENERATED **

# 1.6.1.4 - Ensure SETroubleshoot is not installed (Scored)

yum remove setroubleshoot -y 
