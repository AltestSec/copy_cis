#!/bin/sh
# ** AUTO GENERATED **

# 2.2.2 - Ensure X Window System is not installed (Scored)

yum remove xorg-x11*
