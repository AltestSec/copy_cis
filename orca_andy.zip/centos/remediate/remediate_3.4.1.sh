#!/bin/sh
# ** AUTO GENERATED **

# 3.4.1 - Ensure TCP Wrappers is installed (Scored)

yum install tcp_wrappers -y
yum install tcp_wrappers-libs -y
