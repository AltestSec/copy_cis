#!/bin/sh
# ** AUTO GENERATED **

# 3.4.1 - Ensure TCP Wrappers is installed (Scored)

apt-get install tcpd -y
