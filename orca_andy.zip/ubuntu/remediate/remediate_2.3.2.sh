#!/bin/sh
# ** AUTO GENERATED **

# 2.3.2 - Ensure rsh client is not installed (Scored)

apt-get remove rsh-client rsh-redone-client
