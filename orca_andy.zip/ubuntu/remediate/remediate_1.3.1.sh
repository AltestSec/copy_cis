#!/bin/sh
# ** AUTO GENERATED **

# 1.3.1 - Ensure AIDE is installed (Scored)

apt-get -y install aide aide-common

aideinit
