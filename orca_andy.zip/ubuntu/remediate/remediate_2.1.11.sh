#!/bin/sh
# ** AUTO GENERATED **

# 2.1.11 - Ensure openbsd-inetd is not installed (Scored)

apt-get remove openbsd-inetd
