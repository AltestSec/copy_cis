#!/bin/sh
# ** AUTO GENERATED **

# 4.2.3 - Ensure rsyslog or syslog-ng is installed (Scored)

apt-get install rsyslog -y
apt-get install syslog-ng -y
