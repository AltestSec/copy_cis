#!/bin/sh
# ** AUTO GENERATED **

# 1.6.3 - Ensure SELinux and Apparmor is installed (Scored)

apt-get install selinux
apt-get install apparmor
