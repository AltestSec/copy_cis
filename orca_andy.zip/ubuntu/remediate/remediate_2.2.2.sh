#!/bin/sh
# ** AUTO GENERATED **

# 2.2.2 - Ensure X Window System is not installed (Scored)

apt-get remove xserver-xorg*
