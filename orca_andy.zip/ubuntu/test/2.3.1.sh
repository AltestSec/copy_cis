#!/bin/sh
# ** AUTO GENERATED **

# 2.3.1 - Ensure NIS Client is not installed (Scored)

dpkg -l |grep nis|grep -E "nis" || exit $1
