#!/bin/sh
# ** AUTO GENERATED **

# 1.5.4 - Ensure prelink is disabled (Scored)

apt list|grep prelink|grep -E "prelink"||exit $1

