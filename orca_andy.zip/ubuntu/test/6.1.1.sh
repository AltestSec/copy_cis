#!/bin/sh
# ** AUTO GENERATED **

# 6.1.1 - Audit system file permissions (Not Scored)

dpkg --verify || exit $?
