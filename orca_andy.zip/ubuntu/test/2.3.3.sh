#!/bin/sh
# ** AUTO GENERATED **

# 2.3.3 - Ensure talk client is not installed (Scored)

apt list|grep talk|grep -E "talk"||exit $1
