#!/bin/sh
# ** AUTO GENERATED **

# 2.3.5 - Ensure LDAP client is not installed (Scored)

apt list|grep ldap-utils|grep -E "ldap-utils"||exit $1
