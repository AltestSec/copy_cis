#!/bin/sh
# ** AUTO GENERATED **

# 1.2.1 - Ensure package manager repositories are configured (Not Scored)

apt-cache policy || exit 1
