#!/bin/bash
export PS1="(chroot) $PS1"
username_path="/mnt/ext_storage/rootfs/home/test"


test_home="/mnt/ext_storage/rootfs/home/test"
test_dir="/mnt/ext_storage/rootfs/home/test/nix-benchmark"
test_path="/home/test"
l_test_dir="/home/test/nix-benchmark"



test_home="$mount_path/home/test"
mkdir -p /mnt/ext_storage/rootfs/home/nixadmin/nix-benchmark
cd /mnt/ext_storage/rootfs


mount -t proc none /mnt/ext_storage/rootfs/proc/
mount --rbind /dev /mnt/ext_storage/rootfs/dev/
mount --rbind /sys /mnt/ext_storage/rootfs/sys/
mount --rbind /run /mnt/ext_storage/rootfs/run/
cp -r /home/nixadmin/nix-benchmark/ubuntu/* /mnt/ext_storage/rootfs/home/nixadmin/nix-benchmark
exec chroot /mnt/ext_storage/rootfs /bin/bash << EOF1
cd /home/nixadmin/nix-benchmark
./run-cis.sh
exit
EOF1

umount $mount_path/proc
umount $mount_path/sys
umount $mount_path/dev
umount $mount_path/run